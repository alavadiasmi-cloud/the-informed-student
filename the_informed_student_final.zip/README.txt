# The Informed Student website

A responsive static website for the student-led research and news-literacy initiative.

## Preview locally
Open `index.html` in a web browser. The opening screen asks visitors whether they are students, teachers/educators, or other visitors. Choosing a role opens the website.

## Publish with GitHub Pages
1. Create a GitHub repository (for example, `the-informed-student`).
2. Upload `index.html` to the repository root.
3. Open Settings → Pages.
4. Choose deployment from the `main` branch and `/ (root)`.
5. Save and wait for GitHub Pages to publish the site.

## Visitor analytics (important)
The site does not currently send visitor data anywhere. To count real visitors and role-button interactions, set up a free GoatCounter site at https://www.goatcounter.com/ after publishing. In `index.html`, uncomment/add the script tag in the `<head>` and replace `YOUR-SITE-CODE` with your actual GoatCounter site code:

`<script data-goatcounter="https://YOUR-SITE-CODE.goatcounter.com/count" async src="https://gc.zgo.at/count.js"></script>`

Once configured, page views are counted by GoatCounter and the student/teacher/other entry choices are sent as custom event paths. See your GoatCounter dashboard for counts. Until this is configured, no cross-visitor analytics are collected; a static HTML file cannot reliably count all visitors by itself.

## Privacy
The welcome screen's role choice is not stored on a server by this page. The quiz answers are processed in the browser and are not sent or saved. Analytics will be enabled only after you configure the service above.

## Before publishing
- Confirm every survey statistic against the final dataset (n=30).
- Review the content and add desired author/contact information.
